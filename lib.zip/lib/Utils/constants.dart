import 'package:flutter/material.dart';

final Color kGreen = Color(0xff62B47F);
final Color kGreen10 = Color(0x1A62B47F);
final Color kTextColorGrey = Color(0xff858585);
final Color kBlue = Color(0xff2F81B1);
final Color kOrange = Color(0xffF29339);
final Color kRed = Color(0xffFF0000);
final Color kLightBlue = Color(0xffAEE1FF);
